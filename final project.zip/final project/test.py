from characters import newCharacters
from characters import newBinary

my_file = open("text_input.txt")
my_string = my_file.read()


def build_dictionary(key, diction):  # combines two lists into a dictionary
    dictionary = {}
    for i in range(len(key)):
        dictionary[key[i]] = diction[i]
    return dictionary


dict_code = build_dictionary(newCharacters, newBinary)
print(dict_code)


def code(dictionary, text):  # translate words to binaries
    index = 0
    answer = ""
    while index < len(text):
        for i in range(10, 0, -1):
            if text[index:index + i] in dictionary:
                answer += dictionary[text[index:index + i]]
                index += i
                break
    return answer


codex = code(dict_code, my_string)
print(len(codex))
print(codex)



def decode(dictionary, text):  # translate binaries to words
    index = 0
    answer = ""
    while index < len(text):
        if text[index] == "0":
            answer += dictionary[text[index:index + 5]]
            index += 5
            continue
        if text[index] == "1":
            answer += dictionary[text[index:index + 7]]
            index += 7
    return answer


dict_bin = build_dictionary(newBinary, newCharacters)
print(dict_bin)

decode = decode(dict_bin, codex)
print(decode)

print(decode == my_string)